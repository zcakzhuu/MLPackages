Internal API
############

frontend
========

.. automodule:: xesmf.frontend
    :members:

backend
=======

.. automodule:: xesmf.backend
    :members:

smm
===

.. automodule:: xesmf.smm
    :members:
