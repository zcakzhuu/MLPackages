User API
########

Regridder
=========

.. autoclass:: xesmf.frontend.Regridder
    :members:
    :special-members: __init__, __call__

util
====

.. automodule:: xesmf.util
    :members:

data
====

.. automodule:: xesmf.data
    :members:
