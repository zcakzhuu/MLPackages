import sys

from sentinelsat.scripts.cli import cli as main

sys.exit(main())
