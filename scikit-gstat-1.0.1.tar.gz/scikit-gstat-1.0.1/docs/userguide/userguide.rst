==========
User Guide
==========

This user guide shall help you getting started with ``scikit-gstat`` package
along with a more general introduction to variogram analysis.

.. toctree::
    :maxdepth: 3
    :caption:  Contents

    introduction
    variogram
    kriging