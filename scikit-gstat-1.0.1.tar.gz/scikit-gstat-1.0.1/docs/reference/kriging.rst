=============
Kriging Class
=============

.. autoclass:: skgstat.OrdinaryKriging
    :members:

    .. automethod:: __init__