==========================
DirectionalVariogram Class
==========================

.. autoclass:: skgstat.DirectionalVariogram
    :members:

    .. automethod:: __init__
    .. automethod:: _calc_direction_mask_data
    .. automethod:: _triangle
    .. automethod:: _compass
    .. automethod:: _direction_mask
