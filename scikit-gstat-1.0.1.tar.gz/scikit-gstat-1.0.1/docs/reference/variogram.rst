===============
Variogram Class
===============

.. autoclass:: skgstat.Variogram
    :members:

    .. automethod:: __init__
