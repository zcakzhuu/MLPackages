========================
SpaceTimeVariogram class
========================

.. autoclass:: skgstat.SpaceTimeVariogram
    :members:

    .. automethod:: __init__
