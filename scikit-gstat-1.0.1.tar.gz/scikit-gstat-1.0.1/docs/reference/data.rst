=================
Example data sets
=================

Datasets
--------

.. automodule:: skgstat.data
    :members: pancake, pancake_field, aniso, aniso_field

Utility Functions
-----------------

..automodule:: skgstat.data._loader
    :members: field, get_sample