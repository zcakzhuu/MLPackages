=======================================
MetricSpace - Coordinate representation
=======================================

MetricSpace
===========

.. autoclass:: skgstat.MetricSpace
    :members:

    .. automethod:: __init__
    .. automethod:: find_closest

MetricSpacePair
===============

.. autoclass:: skgstat.MetricSpacePair
    :members:

    .. automethod:: __init__
    .. automethod:: find_closest